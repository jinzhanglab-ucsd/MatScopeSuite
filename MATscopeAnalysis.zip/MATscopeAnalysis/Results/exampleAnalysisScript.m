%% Init
clear
close all
clc

%% read Results 
pth = ''; 
R = Results(pth); % or any subclass of Results

%% update report script file name
R.reportScript = mfilename; 


%% ANALYSIS ....


%% 

